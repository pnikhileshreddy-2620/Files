-- SQL 
-- Structured QUery Language

-- used to cummincate with databases


-- MySQL Workbench

-- RDBMS


-- SELECT -- is used to specify the columnames
-- FROM -- is used to specify the table names

SELECT actor_id,first_name
FROM actor ;


SELECT ACTOR_ID,FIRST_NAME,LAST_NAME 
FROM actor ;

-- SELECT actor_id,first_name
-- FROM actor ;

-- single line comment


/*
multi
line
comment
*/

SELECT ACTOR_ID,FIRST_NAME,LAST_NAME 
FROM actor ;


select film_id,title from film;



/*
sdfargqeg
wgqerg
waewerg
*/


/* sadsfw
ergewrg
wergwerg
ewrgwerg
ergerg
*/


-- SELECT ALL COUMNS WE USE * 

SELECT * FROM film ;


-- WAQ to get all the details of all customers

	SELECT * FROM customer ;
    
    
-- WHERE -- is used to apply filter <filter condition> on rows

SELECT * FROM customer
WHERE customer_id = 5  ;


SELECT customer_id,first_name,email
FROM customer ;


SELECT customer_id,first_name,email
FROM customer
WHERE customer_id = 5 ;

-- get payment details of customer_id 2
-- payment_id,customer_id,amount,payment_date
-- payments table 


SELECT payment_id,customer_id,amount,payment_date
FROM payment
WHERE customer_id = 2 ;


-- Comparison Operators

-- = < > != <>


-- find the lengthy films ( length more than 120 mins)

SELECT film_id,title,length
FROM film
WHERE length > 120 ; -- greater than 120 


SELECT film_id,title,length
FROM film
WHERE length >= 120 ;-- greaterthan or equal to 120

-- get details of films release in year 2006
-- filmid,title,descripton,releaseyear

select film_id, title, description,release_year 
from film 
where release_year = 2006;



-- find all films where replacement cost not equal to 20.99
-- id,title,replacementcost


SELECT film_id,title,replacement_cost
FROM film
WHERE replacement_cost != 20.99 ; -- not equal to 20.99



SELECT film_id,title,replacement_cost
FROM film
WHERE replacement_cost <> 20.99 ; -- not equal to 20.99


-- Logical operators
-- AND  return if all conditions are true
-- OR  return if any one condition is true
-- NOT reverse the result of condition


-- find the films hwere length is more than 120 and rental rate is 2.99

SELECT film_id,title,length,rental_rate
FROM film
WHERE length > 120 AND rental_rate = 2.99  ;

-- find the films hwere length is more than 120 or  rental rate is 2.99

SELECT film_id,title,length,rental_rate
FROM film
WHERE length > 120 OR rental_rate = 2.99  ;


-- FIND the payment details of customerid 2 where amount is greater than 2.99 
-- pay_id,cus_id,amount,pay_date

SELECT payment_id,customer_id,amount,payment_date
FROM payment
WHERE customer_id = 2 and amount > 2.99 ;



-- find the films details where rating is not PG
-- film_id,title,rating

SELECT film_id,title,rating
FROM film
WHERE rating != 'PG' ;   -- "pg"


SELECT film_id,title,rating
FROM film
WHERE NOT rating = "PG" ;


select film_id, title, rating
from film 
where not rating = "PG";



--  RANGE AND MEMBERSHIP OPERATORS

-- IN
-- NOT IN
-- BETWEEN
-- NOT BETWEEN


SELECT film_id,title,rating
FROM film
WHERE rating = 'G'
OR rating = 'PG'
OR RATING = 'R' ;

SELECT film_id,title,rating
FROM film
WHERE rating IN ('G','PG','R') ;


-- find the films which are not rated as G or R or NC-17 

SELECT film_id,title,rating
FROM film
WHERE rating NOT IN ('G','R','NC-17') ;



-- find the films with rental rate bwetween 2.99 and 4.99


SELECT film_id,title,rental_rate
FROM film
WHERE rental_Rate BETWEEN 2.99 AND 4.99 ;


-- FIND THE DETAILS OF CUSTOMERS WHERE CUST ID BETWEEN 5 TO 10
-- ID,FIRST_NAME,EMAIL

select customer_id,first_name,email 
from customer 
where customer_id between 5 and 10;



-- FIND FILMS WHERE LENGTH IF NOT BETWEEN 60 AND 120 
-- FILM_ID,TITLE,LENGTH


SELECT film_id, title, length
FROM film
WHERE length NOT BETWEEN 60 AND 120 ;



SELECT film_id, title, length
FROM film
WHERE NOT length  BETWEEN 60 AND 120 ;



-- ORDER BY 

-- SORT THE RESULT ASC , DESC




SELECT film_id, title, length
FROM film
WHERE length NOT BETWEEN 60 AND 120
ORDER BY length ;



SELECT film_id, title, length
FROM film
WHERE length NOT BETWEEN 60 AND 120
ORDER BY length DESC ;


-- limit 
-- limit the no of rows in the output


select * from customer
limit 10 ;




-- amount
-- 50,
-- 30,
-- 60


-- order by  amount


-- 30,
-- 50,
-- 60


-- order by amount desc, custid

-- 60
-- 50
-- 30



-- find the top 5 lengthy films (based on the length)
-- film_id,title,length


SELECT film_id,title,length
FROM film
ORDER by length desc 
limit 5 ;


SELECT film_id,title,length
FROM film
ORDER by length asc
limit 5 ;




SELECT film_id,title,length
FROM film
ORDER by length ;


SELECT film_id,title,length
FROM film
ORDER by length ASC ;



SELECT amount from payment ;

SELECT SUM(amount) 
from payment ;

SELECT SUM(amount) AS total_payment
from payment ;


SELECT SUM(amount) as total_payment,
min(amount)as min_payment,
max(amount) as max_payment,
count(amount) as transactions,
avg(amount) as avg_payment
from payment ;





-- TOTAL PAYMENTS MADE BY EACH CUSTOMER

SELECT customer_id,sum(amount) as total_payment
FROM PAYMENT
group by customer_id ;


-- find the top 10 customers based on their total payment
-- customer_id, amount



SELECT customer_id,sum(amount) as total_payment
FROM PAYMENT
group by customer_id
order by  total_payment desc 
limit 10 ;


-- for the above customers display the transaction count or payment count




SELECT customer_id,sum(amount) as total_payment,count(amount) as transac_count
FROM PAYMENT
group by customer_id
order by  total_payment desc 
limit 10 ;



